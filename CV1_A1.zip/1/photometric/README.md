# Lab1 - Part1: Photometric stereo

## Instructions

- Extract the data in `photometrics_image.zip` to the same folder, namely `Lab1_Photometric_Color/photometric/`
- In `photometric_stereo.m`, set the path to the desired dataset folder
