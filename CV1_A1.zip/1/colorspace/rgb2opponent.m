function [output_image] = rgb2opponent(input_image)
% converts an RGB image into opponent color space

end

