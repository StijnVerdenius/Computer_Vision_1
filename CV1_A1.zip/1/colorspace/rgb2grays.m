function [output_image] = rgb2grays(input_image)
% converts an RGB into grayscale by using 4 different methods

% ligtness method

% average method
 
% luminosity method

% built-in MATLAB function 

 
end

